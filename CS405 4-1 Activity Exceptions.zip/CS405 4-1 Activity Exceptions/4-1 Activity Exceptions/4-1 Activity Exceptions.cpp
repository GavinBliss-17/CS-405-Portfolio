#include <iostream>
#include <stdexcept> // for standard exceptions
#include <exception> // for custom exceptions

// Custom exception class
class CustomException : public std::exception {
public:
	const char* what() const noexcept override {
		return "Customer exception has occured!";
	}
};

bool do_even_more_custom_application_logic() {
	// Throwing standard runtime error
	std::cout << "Running even more app logic." << std::endl;
	throw std::runtime_error("An error occured in even more custom app logic");
	return true; // Won't be reached due to exception
}

void do_custom_application_logic() {
	try {
		std::cout << "Running custom app logic." << std::endl;
		if (do_even_more_custom_application_logic()) {
			std::cout << "Even more custom app logic succeeded" << std::endl;
		}
	}
	catch (const std::exception& e) {
		// Catching and then displaying the standard exception message
		std::cout << "Caught std::exception: " << e.what() << std::endl;
	}

	// Throwing custom exception
	throw CustomException();

	std::cout << "Leaving custom app logic." << std::endl;  // Won't be reached
}

float divide(float num, float den) {
	// Throwing standard exception for divide by zero case
	if (den == 0) {
		throw std::invalid_argument("Divide by zero error");
	}
	return (num / den);
}

void do_division() noexcept {
	try {
		float numerator = 10.0f;
		float denominator = 0;
		auto result = divide(numerator, denominator);
		std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
	}
	catch (const std::invalid_argument& e) {
		// Catching only the divide by zero exception here
		std::cout << "Caught exception in division: " << e.what() << std::endl;
	}
}

int main() {
	try {
		std::cout << "Exceptions Tests!" << std::endl;

		do_division();
		do_custom_application_logic();

	}
	catch (const CustomException& e) {
		// Catching custom exception
		std::cout << "Caught CustomException: " << e.what() << std::endl;
	}
	catch (const std::exception& e) {
		// Catching standard exceptions
		std::cout << "Caught std::exception in main: " << e.what() << std::endl;
	}
	catch (...) {
		// Catching uncaught exceptions
		std::cout << "Caught an unknown exception." << std::endl;
	}

	return 0;
}